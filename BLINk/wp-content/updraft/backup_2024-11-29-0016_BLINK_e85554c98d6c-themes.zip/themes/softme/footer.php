</div></div>
<footer id="dt_footer" class="dt_footer dt_footer--one clearfix">
	<?php 	
	// Footer Widget
	do_action('softme_footer_widget');

	// Footer Copyright
	do_action('softme_footer_bottom'); 	
	?>
</footer>
<?php 
// Top Scroller
do_action('softme_top_scroller'); 
wp_footer(); ?>
</body>
</html>
