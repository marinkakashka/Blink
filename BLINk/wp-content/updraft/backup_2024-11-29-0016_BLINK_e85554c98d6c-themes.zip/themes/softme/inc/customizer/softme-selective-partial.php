<?php
// softme_hdr_btn_lbl
function softme_hdr_btn_lbl_render_callback() {
	return get_theme_mod( 'softme_hdr_btn_lbl' );
}

// softme_hdr_contact_ttl
function softme_hdr_contact_ttl_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_ttl' );
}

// softme_hdr_contact_txt
function softme_hdr_contact_txt_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_txt' );
}

// softme_hdr_contact_ttl2
function softme_hdr_contact_ttl2_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_ttl2' );
}

// softme_hdr_contact_txt2
function softme_hdr_contact_txt2_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_txt2' );
}

// softme_hdr_contact_ttl3
function softme_hdr_contact_ttl3_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_ttl3' );
}

// softme_hdr_contact_txt3
function softme_hdr_contact_txt3_render_callback() {
	return get_theme_mod( 'softme_hdr_contact_txt3' );
}

// softme_footer_copyright_text
function softme_footer_copyright_text_render_callback() {
	return get_theme_mod( 'softme_footer_copyright_text' );
}