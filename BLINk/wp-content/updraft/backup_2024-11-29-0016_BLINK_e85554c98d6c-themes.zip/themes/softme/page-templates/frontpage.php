<?php 
/**
Template Name: Frontpage
*/

get_header();

do_action( 'Desert_Companion_Softme_frontpage', false);

get_footer(); ?>