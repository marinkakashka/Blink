<?php if ( ! is_active_sidebar( 'storely-sidebar-primary' ) ) {	return; } ?>
<div id="st-secondary-content" class="col-lg-3 mb-lg-0 mb-4">
	<section class="sidebar">
		<?php dynamic_sidebar('storely-sidebar-primary'); ?>
	</section>
</div>